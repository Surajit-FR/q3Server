export const EXPRESS_CONFIG_LIMIT = "15kb";
export const DB_NAME = 'q3'